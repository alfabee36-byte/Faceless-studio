import os, requests
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
def youtube(video, thumb, meta, token_file, lang):
    yt = build("youtube", "v3", credentials=Credentials.from_authorized_user_file(token_file))
    body = {"snippet": {"title": meta["title"][:100], "description": meta["description"], "tags": meta["tags"],
            "categoryId": "22", "defaultAudioLanguage": lang},
            "status": {"privacyStatus": "public", "containsSyntheticMedia": True}}  # disclosure AI jujur
    r = yt.videos().insert(part="snippet,status", body=body, media_body=MediaFileUpload(video, resumable=True)).execute()
    try: yt.thumbnails().set(videoId=r["id"], media_body=MediaFileUpload(thumb)).execute()
    except Exception: pass  # thumbnail custom butuh channel terverifikasi
    return r["id"]
def public_url(path): return f"{os.environ['PUBLIC_BASE_URL'].rstrip('/')}/{path}"
def instagram(video, meta):
    u, t = os.environ["IG_USER_ID"], os.environ["IG_TOKEN"]; g = f"https://graph.facebook.com/v21.0/{u}"
    c = requests.post(f"{g}/media", data=dict(media_type="REELS", video_url=public_url(video),
        caption=meta["title"] + "\n" + " ".join("#" + x.replace(" ", "") for x in meta["tags"][:8]), access_token=t)).json()
    return requests.post(f"{g}/media_publish", data=dict(creation_id=c["id"], access_token=t)).json()
def facebook(video, meta):
    return requests.post(f"https://graph-video.facebook.com/v21.0/{os.environ['FB_PAGE_ID']}/videos",
        data=dict(title=meta["title"], description=meta["description"], access_token=os.environ["FB_TOKEN"]),
        files={"source": open(video, "rb")}).json()
def tiktok(video, meta):
    return requests.post("https://open.tiktokapis.com/v2/post/publish/video/init/",
        headers={"Authorization": f"Bearer {os.environ['TIKTOK_TOKEN']}"},
        json={"post_info": {"title": meta["title"][:150], "privacy_level": "SELF_ONLY", "is_aigc": True},
              "source_info": {"source": "PULL_FROM_URL", "video_url": public_url(video)}}).json()
