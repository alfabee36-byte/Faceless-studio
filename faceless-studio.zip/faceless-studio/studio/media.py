import os, subprocess, requests, pathlib
from PIL import Image, ImageDraw, ImageFont
VOICES = {"en": "21m00Tcm4TlvDq8ikWAM"}  # ganti voice_id per bahasa; fallback ke "en"
def sh(*a): subprocess.run(a, check=True, capture_output=True)
def dur(p): return float(subprocess.check_output(["ffprobe","-v","error","-show_entries","format=duration","-of","csv=p=0",p]))
def tts(text, lang, out):
    r = requests.post(f"https://api.elevenlabs.io/v1/text-to-speech/{VOICES.get(lang, VOICES['en'])}",
        headers={"xi-api-key": os.environ["ELEVENLABS_API_KEY"]},
        json={"text": text, "model_id": "eleven_multilingual_v2"}); r.raise_for_status()
    open(out, "wb").write(r.content); return out
def clip(scene, fmt, out):
    """Adapter video model. Tambah provider (Veo/Runway/Kling: image->video + camera motion control) di sini."""
    prov = os.getenv("VIDEO_PROVIDER", "pexels")
    if prov == "pexels":
        o = "portrait" if fmt == "short" else "landscape"
        v = requests.get("https://api.pexels.com/videos/search", headers={"Authorization": os.environ["PEXELS_API_KEY"]},
            params=dict(query=scene["visual_prompt"][:80], orientation=o, per_page=1)).json()["videos"][0]
        f = max(v["video_files"], key=lambda x: x["width"])
        open(out, "wb").write(requests.get(f["link"]).content); return out
    raise NotImplementedError(f"Isi adapter {prov}: kirim visual_prompt + camera_motion, simpan mp4 ke {out}")
def srt(scenes, total, out):
    n = sum(len(s["narration"]) for s in scenes); t = 0; lines = []
    ts = lambda x: f"{int(x//3600):02}:{int(x%3600//60):02}:{int(x%60):02},{int(x%1*1000):03}"
    for i, s in enumerate(scenes, 1):
        d = total * len(s["narration"]) / n
        lines.append(f"{i}\n{ts(t)} --> {ts(t+d)}\n{s['narration']}\n"); t += d
    open(out, "w", encoding="utf-8").write("\n".join(lines)); return out
def render(script, lang, fmt, workdir):
    w = pathlib.Path(workdir); w.mkdir(parents=True, exist_ok=True)
    voice = tts(" ".join(s["narration"] for s in script["scenes"]), lang, str(w/"voice.mp3"))
    total = dur(voice); per = total / len(script["scenes"])
    W, H = (1080, 1920) if fmt == "short" else (1920, 1080); parts = []
    for i, s in enumerate(script["scenes"]):
        raw = clip(s, fmt, str(w/f"raw{i}.mp4")); p = str(w/f"p{i}.mp4")
        sh("ffmpeg","-y","-stream_loop","-1","-i",raw,"-t",f"{per:.2f}","-vf",
           f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},fps=30","-an",p); parts.append(p)
    open(w/"list.txt","w").write("".join(f"file '{pathlib.Path(p).resolve()}'\n" for p in parts))
    sub = srt(script["scenes"], total, str(w/"s.srt")); out = str(w/"final.mp4")
    sh("ffmpeg","-y","-f","concat","-safe","0","-i",str(w/"list.txt"),"-i",voice,"-vf",
       f"subtitles={sub}:force_style='FontSize=18,Outline=2,Alignment=2'","-c:v","libx264","-c:a","aac","-shortest",out)
    return out, thumb(script["thumbnail"], W, H, str(w/"thumb.jpg"))
def thumb(t, W, H, out):
    im = Image.new("RGB", (W, H), (20, 20, 30)); d = ImageDraw.Draw(im)
    try: f = ImageFont.truetype("DejaVuSans-Bold.ttf", H // 8)
    except OSError: f = ImageFont.load_default()
    d.text((W//10, H//3), t["text"], fill="white", font=f); im.save(out, quality=90); return out
