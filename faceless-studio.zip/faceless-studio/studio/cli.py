import typer, json
from dotenv import load_dotenv; load_dotenv()
from . import db, pipeline, research
app = typer.Typer()
@app.command()
def report(niche: str, market: str):
    """Deep research per negara -> JSON."""
    typer.echo(json.dumps(research.market_report(niche, market), indent=2, ensure_ascii=False))
@app.command()
def produce(channel: str = ""):
    """Riset -> script -> terjemah -> voice -> video -> thumbnail."""
    for c in pipeline.channels():
        if not channel or c["id"] == channel: pipeline.produce(c)
@app.command()
def review():
    for j in db.by_status("pending_review"): typer.echo(f"{j[0]} [{j[1]}/{j[3]}] {j[2]} -> {j[4]}")
@app.command()
def approve(job_id: int): db.set_status(job_id, "approved")
@app.command()
def publish():
    for j in db.by_status("approved"): typer.echo(pipeline.publish(j))
@app.command()
def daily():
    """Untuk cron: produce + publish yang sudah approved."""
    produce(""); publish()
if __name__ == "__main__": app()
