import yaml, json, hashlib
from . import db, research, script as sc, translate, media, upload
def channels(): return yaml.safe_load(open("config/channels.yaml"))["channels"]
def produce(ch):
    rep, topics = research.pick_topics(ch["niche"], ch["market"], db.used_topics(ch["id"]), min(ch["videos_per_day"], 5))
    base = research.market(ch["market"])["lang"]
    for t in topics:
        s = sc.write(t, ch["niche"], ch["market"], ch["format"]); h = hashlib.md5(t["title"].encode()).hexdigest()[:8]
        for lang in [base] + ch.get("translate_to", []):
            v = s if lang == base else translate.localize(s, lang)
            out, th = media.render(v, lang, ch["format"], f"output/{ch['id']}/{h}_{lang}")
            db.add(ch["id"], t["title"], lang, "approved" if ch["auto_publish"] else "pending_review", out, {**v, "thumb": th})
def publish(job):
    i, chid, topic, lang, path, meta = job; meta = json.loads(meta)
    ch = next(c for c in channels() if c["id"] == chid); r = {}
    if "youtube" in ch["platforms"]: r["yt"] = upload.youtube(path, meta["thumb"], meta, ch["token_file"], lang)
    if "instagram" in ch["platforms"] and ch["format"] == "short": r["ig"] = upload.instagram(path, meta)
    if "facebook" in ch["platforms"]: r["fb"] = upload.facebook(path, meta)
    if "tiktok" in ch["platforms"] and ch["format"] == "short": r["tt"] = upload.tiktok(path, meta)
    db.set_status(i, "published"); return r
