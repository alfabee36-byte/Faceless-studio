import os, json, re, anthropic
_cl = anthropic.Anthropic()
def ask(system, prompt, max_tokens=4000):
    r = _cl.messages.create(model=os.getenv("LLM_MODEL", "claude-sonnet-5-5"), max_tokens=max_tokens,
                            system=system, messages=[{"role": "user", "content": prompt}])
    return r.content[0].text
def ask_json(system, prompt, max_tokens=4000):
    t = ask(system + "\nReturn ONLY valid JSON.", prompt, max_tokens)
    return json.loads(re.search(r"[\[{].*[\]}]", t, re.S).group(0))
